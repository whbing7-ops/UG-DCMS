"""健康检查与系统自证端点。"""
from __future__ import annotations

from fastapi import APIRouter

from ..db import fetch_all, fetch_one, scalar
from ..txroute import TransactionalRoute
from ..deps import Conn, CurrentUser

router = APIRouter(tags=["系统"], route_class=TransactionalRoute)


@router.get("/health")
def health(conn: Conn):
    """存活探针。不需要认证, 供 Docker healthcheck 与反向代理使用。"""
    ok = scalar(conn, "SELECT 1") == 1
    return {"status": "ok" if ok else "degraded"}


@router.get("/system/invariants")
def invariants(conn: Conn, user: CurrentUser):
    """列出系统不变量及其强制手段 — 支撑 IVV §8 的可追溯性要求。

    这个端点存在的意义是: 验收时不必翻源码, 直接问系统"你都强制了哪些规则、
    分别靠什么强制"。
    """
    return fetch_all(conn, """
        SELECT code, statement_cn, enforced_by, enforcement_ref, test_ref
          FROM invariant_registry ORDER BY code
    """)


@router.get("/system/migrations")
def migrations(conn: Conn, user: CurrentUser):
    """已应用的数据库迁移版本 — IVV §8 要求 Migration 版本可追溯。"""
    exists = scalar(conn, """
        SELECT EXISTS (SELECT 1 FROM information_schema.tables
                        WHERE table_name = 'schema_migration')
    """)
    if not exists:
        return []
    return fetch_all(conn, """
        SELECT version, filename, sha256, applied_at, applied_by, duration_ms
          FROM schema_migration ORDER BY version
    """)


@router.get("/system/dictionary-status")
def dictionary_status(conn: Conn, user: CurrentUser):
    """字典装载自检: 条目数与占位残留。上线前应确认占位数为 0。"""
    return fetch_one(conn, """
        SELECT (SELECT count(*) FROM physical_class)    AS physical_class,
               (SELECT count(*) FROM naming_core_term)  AS core_term,
               (SELECT count(*) FROM naming_qualifier)  AS qualifier,
               (SELECT count(*) FROM function_domain)   AS function_domain,
               (SELECT count(*) FROM function_item)     AS function_item,
               (SELECT count(*) FROM restricted_term)   AS restricted_term,
               (SELECT count(*) FROM physical_class   WHERE definition LIKE '[占位]%%')
             + (SELECT count(*) FROM naming_core_term WHERE definition LIKE '[占位]%%')
             + (SELECT count(*) FROM naming_qualifier WHERE definition LIKE '[占位]%%')
             + (SELECT count(*) FROM function_item    WHERE definition LIKE '[占位]%%')
                                                            AS placeholder_remaining
    """)
